package com.example.springbootssm;

import com.example.springbootssm.dao.deptdao.DeptDao;
import com.example.springbootssm.dao.testdao.TestUserMapper;
import com.example.springbootssm.dao.userdao.UserDao;
import com.example.springbootssm.pojo.User;
import com.example.springbootssm.service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringBootSsmApplicationTests {
    @Resource
    private DeptDao deptDao;
    @Test
    public void contextLoads() {
        System.out.println(deptDao.deptSelectAll());
    }

}
