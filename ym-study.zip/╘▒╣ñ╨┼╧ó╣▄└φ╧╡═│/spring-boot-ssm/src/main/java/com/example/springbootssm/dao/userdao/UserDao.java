package com.example.springbootssm.dao.userdao;

import java.util.List;

import com.example.springbootssm.pojo.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.springframework.stereotype.Repository;

public interface UserDao {
	//���˺ź������ѯ�û�
	@Select("select * from user_inf where loginname=#{loginname} and password=#{password}")
	User userSelectByLoginnameAndPassword(@Param("loginname") String loginname,
										  @Param("password") String password);
	
	//�����û������û�״̬����ģ����ѯ
	@SelectProvider(type =  com.example.springbootssm.dao.userdao.UserDynamicSql.class,method = "userSelectByUserNameOrUserStatus")
	List<User> userSelectByUserNameOrUserStatus(@Param("username") String username, @Param("userstatus") String userstatus);
	
	//��ѯ�����û�
	@Select("select * from user_inf")
	List<User> userSelectAll();
	
	//ʹ��id��ѯ�û�
	@Select("select * from user_inf where id=#{id}")
	User userSelectById(Integer id);
	
	//ʹ��loginname��ѯ�û�
	@Select("select * from user_inf where loginname=#{loginname}")
	User userSelectByLoginame(String loginname);
	
	//�����û�
	@Insert("insert into user_inf(loginname,password,username,userstatus) values(#{loginname},#{password},#{username},#{userstatus})")
	@Options(useGeneratedKeys = true,keyProperty = "id")	
	void userInsert(User user) ;
	
	//ɾ���û�
	@Delete("delete from user_inf where id= #{id}")
	void userDelete(Integer id);
	
	//�޸��û�
	@UpdateProvider(type =  com.example.springbootssm.dao.userdao.UserDynamicSql.class,method = "userUpdate")
	void userupdate(User user);
	
}
