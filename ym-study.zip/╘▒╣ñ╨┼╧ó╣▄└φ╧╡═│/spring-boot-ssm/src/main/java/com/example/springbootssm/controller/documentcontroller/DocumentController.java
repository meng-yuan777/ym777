package com.example.springbootssm.controller.documentcontroller;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.springbootssm.pojo.Document;
import com.example.springbootssm.pojo.User;
import com.example.springbootssm.service.DocumentService;
import org.apache.commons.io.FileUtils;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class DocumentController {
	@Resource
	private DocumentService documentService;

	@PostMapping("/upload")
	public void fileUpLoda(HttpServletRequest request, HttpServletResponse Response,
			@RequestParam("file") MultipartFile uploadfile, @ModelAttribute Document document)
			throws IllegalStateException, IOException {
		User user = (User) request.getSession().getAttribute("user");
		if (uploadfile != null) {
			File file = new File("E:\\文件\\" + user.getLoginname() + "\\" + uploadfile.getOriginalFilename());
			System.out.println("�ϴ����ļ���"+uploadfile.getOriginalFilename());
			if (!file.getParentFile().exists()) {
				file.getParentFile().mkdirs();
			}
			uploadfile.transferTo(file);
			document.setUser(user);
			document.setFilename(uploadfile.getOriginalFilename());
			documentService.documentInsert(document);
		}
	}

	@RequestMapping("/documentfindpage")
	public ModelAndView documentFind(ModelAndView mav) {
		List<Document> documents = documentService.documentSelectAll();
		mav.addObject("documents", documents);
		mav.setViewName("documentfindpage");
		return mav;
	}

	@RequestMapping("/documentdelete/{ids}")
	public String documentDelete(HttpServletResponse response, HttpServletRequest request,
			@PathVariable("ids") String ids) {
		User user = (User) request.getSession().getAttribute("user");
		for (String id : ids.split(",")) {
			int document_id = Integer.parseInt(id);
			Document document = documentService.documentSelectById(document_id);
			File file = new File("E:\\文件\\" + user.getLoginname() + "\\" + document.getFilename());
			if (file.exists()) {
				System.out.println("�ļ�����");
				file.delete();
				}
			documentService.documentDelete(document_id);
		}
		return "redirect:/documentfindpage";
	}

	@RequestMapping("/download")
	//ResponseEntity������Է����Զ����BodyHeaders,BodyBuilder,HttpStatus
	public ResponseEntity<byte[]> fileDownload(HttpServletRequest request, @RequestParam("filename") String filename,
			@RequestHeader("User-Agent") String agent) throws IOException {
		User user = (User) request.getSession().getAttribute("user");
		File file = new File("E:\\文件\\" + user.getLoginname() + "\\" + filename);
		filename = URLEncoder.encode(filename, "UTF-8");
		BodyBuilder builder = ResponseEntity.ok();
		builder.contentLength(file.length());
		builder.contentType(MediaType.APPLICATION_OCTET_STREAM);
		//Content-Disposition�������ڶԻ���,attachment�������ʾ�򿪻򱣴�
		if(agent.contains("MSIE"))
			builder.header("Content-Disposition", "attachment;filename="+filename);
		else {
			builder.header("Content-Disposition", "attachment;filename*=UTF-8''"+filename);
		}
		//apache commons
		return builder.body(FileUtils.readFileToByteArray(file));
	}
	@ExceptionHandler(value=IOException.class)
	public ModelAndView ExceptionResolver(Exception exception,ModelAndView mav) {
		mav.addObject("ex", exception.getMessage());
		mav.setViewName("error");
		return mav;
	}
}
