package com.example.springbootssm.controller.deptcontroller;

import java.util.List;

import javax.annotation.Resource;

import com.example.springbootssm.pojo.Dept;
import com.example.springbootssm.service.DeptService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class DeptController {
	@Resource
	private DeptService deptService;
	
	@GetMapping("/deptfindpage")
	public ModelAndView deptAllSelect(ModelAndView mav) {
		List<Dept> depts=deptService.deptSelectAll();
		mav.addObject("depts", depts);
		mav.setViewName("deptfindpage");
		return mav;
	}
	
	@GetMapping("/deptdelete/{deptids}")
	public String deptDelete(ModelAndView mav,@PathVariable("deptids") String deptids) {
		if(deptids.contains(",")) {
			for(String id:deptids.split(",")) {
				System.out.println(id);
				deptService.deptDelete(Integer.parseInt(id));
			}
		}
		else {
			deptService.deptDelete(Integer.parseInt(deptids));
		}
		return "redirect:/deptfindpage";
	}
	
	@GetMapping("/deptselect")
	public ModelAndView userselect(@ModelAttribute Dept dept, ModelAndView mav) {
		List<Dept> depts=deptService.deptSelectByName(dept);
		mav.addObject("depts", depts);
		mav.setViewName("deptfindpage");
		return mav;
	}
	
	@RequestMapping(value="/deptinsert")
	public void userinsert(@RequestBody Dept dept) {
		System.out.println(dept.toString());
		deptService.deptInsert(dept);;
	}
}
