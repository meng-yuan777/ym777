package com.example.springbootssm.interceptor;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.springbootssm.pojo.User;
import com.example.springbootssm.service.UserService;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
@Component
public class UserLoginInterceptor implements HandlerInterceptor {
	private static String INGORE_URL[] = { "/login", "/loginpage" };
	private static boolean COOKIE_EXISTS = false;
	private boolean LOGIN_FLAG = false;
	@Resource
	private UserService userService;

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		System.out.println("进入拦截器");
		// TODO Auto-generated method stub
		if (COOKIE_EXISTS == false) {
			Cookie cookies[] = request.getCookies();
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("personnel_management_system_user")) {
					String userinformationString[] = cookie.getValue().split("#");
					System.out.println("cookie�е�md5����:"+userinformationString[1]);
					User user = userService.userSelectByLoginame(userinformationString[0]);
					System.out.println("密码和cookie是否相同"+userinformationString[1].equals(DigestUtils.md5DigestAsHex(user.getPassword().getBytes("UTF-8"))));
					if (userinformationString[1].equals( DigestUtils.md5DigestAsHex(user.getPassword().getBytes("UTF-8")))) {
						request.getSession().setAttribute("user", user);
						COOKIE_EXISTS = true;
						LOGIN_FLAG = true;
						response.sendRedirect("/index");
//						request.getRequestDispatcher("redirect:/index").forward(request, response);
						return LOGIN_FLAG;
					}
				}
			}
		} 
		for(String url:INGORE_URL)
		{
			if(url.contains(request.getServletPath())) {
				LOGIN_FLAG=true;
				if(COOKIE_EXISTS==true) {
//					request.getRequestDispatcher("redirect:/index").forward(request, response);
					response.sendRedirect("/index");
					return LOGIN_FLAG;

				}
				return LOGIN_FLAG;
			}
		}
		if(LOGIN_FLAG==false){
			User user = (User) request.getSession().getAttribute("user");
			if(user==null) {
//				request.getRequestDispatcher("redirect:/loginpage").forward(request, response);
				response.sendRedirect("/loginpage");
				return LOGIN_FLAG;
			}
			LOGIN_FLAG=true;
		}

		return LOGIN_FLAG;
	}

}
