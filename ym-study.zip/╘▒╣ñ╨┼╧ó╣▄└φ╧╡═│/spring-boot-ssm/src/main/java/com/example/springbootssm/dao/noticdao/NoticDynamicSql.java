package com.example.springbootssm.dao.noticdao;


import com.example.springbootssm.pojo.Notic;
import org.apache.ibatis.jdbc.SQL;


public class NoticDynamicSql {
	
	//����ģ����ѯ
	public String noticSelectByTitleAndContent(String title,String content) {
		return new SQL() {
			{
				SELECT("*");
				FROM("notic_inf");
				if(title!=null)
					WHERE("title like '%"+title+"%'");
				if(content!=null)
					WHERE("content like '%"+content+"%'");
			}
		}.toString();
	}
	
	//�û����µĶ�̬SQL
	public String noticUpdate(Notic notic) {
		return new SQL() {
			{
				UPDATE("notic_inf");
				if(notic.getContent()!=null)
					SET("content=#{content}");
				if(notic.getTitle()!=null)
					SET("title=#{title}");
				WHERE("id=#{id}");
			}
			}.toString();
	}
}
