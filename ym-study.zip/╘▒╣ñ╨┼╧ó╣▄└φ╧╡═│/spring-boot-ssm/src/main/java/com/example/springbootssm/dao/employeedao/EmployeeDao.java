package com.example.springbootssm.dao.employeedao;

import java.util.List;
import java.util.Map;

import com.example.springbootssm.pojo.Employee;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.mapping.FetchType;
import org.springframework.stereotype.Repository;

@Repository("employeeDao")
public interface EmployeeDao {
	
	//����Ա��
	@Insert("insert into employee_inf(dept_id,job_id,name,card_id,address,phone,sex,birthday,mail) "
			+ "values(#{dept.id},#{job.id},#{name},#{card_id},#{address},#{phone},#{sex},#{birthday},#{mail})")
	@Options(useGeneratedKeys = true,keyProperty = "id")
	void employeeInsert(Employee employee) ;
	
	//ɾ��Ա��
	@Delete("Delete from employee_inf where id=#{id}")
	void employeeDelete(Integer id);
	
	//�޸�Ա��
	@UpdateProvider(type = com.example.springbootssm.dao.employeedao.EmployeeDynamicSql.class,method = "employeeUpdate")
	void employeeUpdate(Employee employee);
	
	//����ģ����ѯ
	List<Employee> employeeSelectByInformation(Map<String, Object> param);
	
	//��ѯ����Ա��
	@Select("select * from employee_inf")
	@Results({
		@Result(id=true,property = "id",column = "id"),
		@Result(property = "name",column = "name"),
		@Result(property = "sex",column = "sex"),
		@Result(property = "phone",column = "phone"),
		@Result(property = "address",column = "address"),
		@Result(property = "birthday",column = "birthday"),
		@Result(property = "mail",column = "mail"),
		@Result(property = "card_id",column = "card_id"),
		@Result(property = "createdate",column = "createdate"),
		@Result(property = "dept",column = "dept_id",
		one = @One(select = "com.example.springbootssm.dao.deptdao.DeptDao.deptSelectById",fetchType=FetchType.EAGER)),
		@Result(property = "job",column = "job_id",
		one = @One(select = "com.example.springbootssm.dao.jobdao.JobDao.jobSelectById",fetchType=FetchType.EAGER)),
	})
	List<Employee> employeeSelectAll();
}
