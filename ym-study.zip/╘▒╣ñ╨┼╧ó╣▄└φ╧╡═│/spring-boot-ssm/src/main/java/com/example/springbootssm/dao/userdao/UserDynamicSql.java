package com.example.springbootssm.dao.userdao;


import com.example.springbootssm.pojo.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;


public class UserDynamicSql {
	//�û����µĶ�̬SQL
	public String userUpdate(User user) {
		return new SQL() {
			{
				UPDATE("user_inf");
				if(user.getLoginname()!=null)
					SET("loginname=#{loginname}");
				if(user.getPassword()!=null)
					SET("password=#{password}");
				if(user.getUsername()!=null)
					SET("username=#{username}");
				if(user.getUserstatus()!=null)
					SET("userstatus=#{userstatus}");
				WHERE("id=#{id}");
			}
			}.toString();
	}
	
	//�û�ģ������ѯ�Ķ�̬SQL
	public String userSelectByUserNameOrUserStatus(@Param("username") String username,@Param("userstatus") String userstatus) {
		return new SQL() {
			{
				SELECT("*");
				FROM("user_inf");
				if(username!=null)
					WHERE("username like '%"+username+"%'");
				if(userstatus!=null)
					WHERE("userstatus like '%"+userstatus+"%'");
			}
		}.toString();
	}
}
