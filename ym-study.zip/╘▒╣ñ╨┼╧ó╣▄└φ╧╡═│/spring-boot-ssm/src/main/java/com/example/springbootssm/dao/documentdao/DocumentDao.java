package com.example.springbootssm.dao.documentdao;

import java.util.List;

import com.example.springbootssm.pojo.Document;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.mapping.FetchType;
import org.springframework.stereotype.Repository;

public interface DocumentDao {

	//�����ļ�
	@Insert("insert into document_inf(title,content,user_id,filename) values(#{title},#{content},#{user.id},#{filename})")
	@Options(useGeneratedKeys = true,keyProperty = "id")
	void documentInsert(Document document) ;
	
	//ɾ���ļ�
	@Delete("delete from document_inf where id=#{id}")
	void documentDelete(Integer id);
	
	//�޸��ļ�
	@UpdateProvider(type = com.example.springbootssm.dao.documentdao.DocumentDynamicSql.class,method = "documentUpdate")
	void documentUpdate(Document document);
	
	//��ѯ�����ļ�
	@Select("select * from document_inf")
	@Results({
		@Result(id=true,property = "id",column = "id"),
		@Result(property = "title",column = "title"),
		@Result(property = "content",column = "content"),
		@Result(property = "createdate",column = "createdate"),
		@Result(property = "filename",column = "filename"),
		@Result(property = "user",column = "user_id",
		one=@One(select = "com.example.springbootssm.dao.userdao.UserDao.userSelectById",fetchType = FetchType.EAGER))
	})
	List<Document> documentSelectAll();
	
	//���ݹ����������ݽ���ģ����ѯ
	@SelectProvider(type =  com.example.springbootssm.dao.documentdao.DocumentDynamicSql.class,method = "documentSelectByTitleAndContent")
	@Results({
		@Result(id=true,property = "id",column = "id"),
		@Result(property = "title",column = "title"),
		@Result(property = "content",column = "content"),
		@Result(property = "createdate",column = "createdate"),
		@Result(property = "filename",column = "filename"),
		@Result(property = "user",column = "user_id",
		one=@One(select = "com.example.springbootssm.dao.userdao.UserDao.userSelectById",fetchType = FetchType.EAGER))
	})
	List<Document> documentSelectByTitleAndContent(Document document);
	
	//��ѯ��id��ѯ�ļ�
		@Select("select * from document_inf where id=#{id}")
		@Results({
			@Result(id=true,property = "id",column = "id"),
			@Result(property = "title",column = "title"),
			@Result(property = "content",column = "content"),
			@Result(property = "createdate",column = "createdate"),
			@Result(property = "filename",column = "filename"),
			@Result(property = "user",column = "user_id",
			one=@One(select = "com.example.springbootssm.dao.userdao.UserDao.userSelectById",fetchType = FetchType.EAGER))
		})
		Document documentSelectById(int id);
}
