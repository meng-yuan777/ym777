package com.example.springbootssm.dao.noticdao;

import java.util.List;

import com.example.springbootssm.pojo.Notic;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.mapping.FetchType;
import org.springframework.stereotype.Repository;

@Repository("noticDao")
public interface NoticDao {
	
	//��������
	@Insert("insert into notic_inf(title,content,user_id) values(#{title},#{content},#{user_id})")
	@Options(useGeneratedKeys = true,keyProperty = "id")
	void noticInsert(Notic notic) ;
	
	//ɾ������
	@Select("select * from notic_inf where id=#{id}")
	void noticDelete(Integer id);
	
	//�޸Ĺ���
	@UpdateProvider(type =  com.example.springbootssm.dao.noticdao.NoticDynamicSql.class,method = "noticUpdate")
	void noticUpdate(Notic notic);
	
	//��ѯ���й���
	@Select("select * from notic_inf")
	@Results({
		@Result(id=true,property = "id",column = "id"),
		@Result(property = "title",column = "title"),
		@Result(property = "content",column = "content"),
		@Result(property = "createdate",column = "createdate"),
		@Result(property = "user",column = "userid",
		one=@One(select = "pers.ym.personnel_management_system.dao.userdao.UserDao.userSelectById",fetchType = FetchType.EAGER))
	})
	List<Notic> noticSelectAll();
	
	//���ݹ����������ݽ���ģ����ѯ
	@SelectProvider(type =  com.example.springbootssm.dao.noticdao.NoticDynamicSql.class,method = "noticSelectByTitleAndContent" )
	@Results({
		@Result(id=true,property = "id",column = "id"),
		@Result(property = "title",column = "title"),
		@Result(property = "content",column = "content"),
		@Result(property = "createdate",column = "createdate"),
		@Result(property = "user",column = "userid",
		one=@One(select = " com.example.springbootssm.dao.UserDao.userSelectById",fetchType = FetchType.EAGER))
	})
	List<Notic> noticSelectByTitleAndContent(@Param("title") String title, @Param("content") String content);
	
	
}
