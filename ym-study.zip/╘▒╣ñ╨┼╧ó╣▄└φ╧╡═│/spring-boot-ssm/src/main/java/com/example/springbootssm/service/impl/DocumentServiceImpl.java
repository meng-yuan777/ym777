package com.example.springbootssm.service.impl;

import java.util.List;


import javax.annotation.Resource;

import com.example.springbootssm.dao.documentdao.DocumentDao;
import com.example.springbootssm.pojo.Document;
import com.example.springbootssm.service.DocumentService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("documentService")

public class DocumentServiceImpl implements DocumentService {

	@Resource
	private DocumentDao documentDao;

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void documentInsert(Document document) {
		// TODO Auto-generated method stub
		documentDao.documentInsert(document);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void documentDelete(Integer id) {
		// TODO Auto-generated method stub
		documentDao.documentDelete(id);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void documentUpdate(Document document) {
		// TODO Auto-generated method stub
		documentDao.documentUpdate(document);
	}

	@Override
	public List<Document> documentSelectAll() {
		// TODO Auto-generated method stub
		return documentDao.documentSelectAll();
	}

	@Override
	public List<Document> documentSelectByTitleAndContent(Document document) {
		// TODO Auto-generated method stub
		return documentDao.documentSelectByTitleAndContent(document);
	}

	@Override
	public Document documentSelectById(int id) {
		// TODO Auto-generated method stub
		return documentDao.documentSelectById(id);
	}
	
	
}
