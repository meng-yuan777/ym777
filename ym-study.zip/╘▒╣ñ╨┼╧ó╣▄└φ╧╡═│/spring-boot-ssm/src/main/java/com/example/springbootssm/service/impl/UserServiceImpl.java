package com.example.springbootssm.service.impl;


import java.util.List;

import javax.annotation.Resource;

import com.example.springbootssm.dao.userdao.UserDao;
import com.example.springbootssm.pojo.User;
import com.example.springbootssm.service.UserService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("userService")

public class UserServiceImpl implements UserService {
	@Resource
	private UserDao userDao=null;
	
	@Override
	public User userSelectByLoginnameAndPassword(String loginname, String password) {
		// TODO Auto-generated method stub
		return userDao.userSelectByLoginnameAndPassword(loginname,password);
	}
	
	@Override
	public List<User> userSelectByUserNameOrUserStatus(String username,String userstatus) {
		// TODO Auto-generated method stub
		return userDao.userSelectByUserNameOrUserStatus(username, userstatus);
	}
	
	@Override
	public List<User> userSelectAll() {
		// TODO Auto-generated method stub
		return userDao.userSelectAll();
	}
	
	@Override
	public User userSelectById(Integer id) {
		// TODO Auto-generated method stub
		return userDao.userSelectById(id);
	}
	
	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void userInsert(User user) {
		// TODO Auto-generated method stub
		userDao.userInsert(user);
	}
	
	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void userDelete(Integer id) {
		// TODO Auto-generated method stub
		userDao.userDelete(id);
	}
	
	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void userupdate(User user) {
		// TODO Auto-generated method stub
		userDao.userupdate(user);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public User userSelectByLoginame(String loginname) {
		// TODO Auto-generated method stub
		return userDao.userSelectByLoginame(loginname);
	}
	
	
}
