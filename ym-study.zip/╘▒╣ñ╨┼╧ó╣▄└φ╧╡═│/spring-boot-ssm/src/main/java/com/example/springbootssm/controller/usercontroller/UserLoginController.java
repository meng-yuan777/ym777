package com.example.springbootssm.controller.usercontroller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.springbootssm.pojo.User;
import com.example.springbootssm.service.UserService;
import com.example.springbootssm.utils.CookieUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserLoginController {
	
	@Resource
	private UserService userService=null;
	@PostMapping("/login")
	public void userLogin(@ModelAttribute User user,
			HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
		String message="";
		System.out.println("����");
		user=userService.userSelectByLoginnameAndPassword(user.getLoginname(), user.getPassword());
		if(user!=null)
		{
			request.getSession().setAttribute("user", user);
			Cookie cookie= CookieUtil.cookieFind(user, request);
			if(cookie!=null)
				response.addCookie(cookie);
		}
		else {
			message="�˺Ż��������";
		}
		try {
			response.getWriter().println(message);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
