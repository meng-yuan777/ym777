package com.example.springbootssm.utils;

import java.io.UnsupportedEncodingException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import com.example.springbootssm.pojo.User;
import org.springframework.util.DigestUtils;

public class CookieUtil {
	
	public static Cookie cookieFind(User user, HttpServletRequest request) throws UnsupportedEncodingException {
		int cookieExists=0;
		Cookie cookie=null;
		Cookie cookies[]=request.getCookies();
		for(Cookie c:cookies) {
			if(c.getName().equals("personnel_management_system_user")) {
				c.setValue(user.getLoginname()+"#"+DigestUtils.md5DigestAsHex(user.getPassword().getBytes("UTF-8")));
				c.setMaxAge(30*24*60*60);
				cookieExists=1;
				return c;
			}
		}
		if(cookieExists==0) {
			cookie=new Cookie("personnel_management_system_user",user.getLoginname()+"#"+DigestUtils.md5DigestAsHex(user.getPassword().getBytes("UTF-8")));
			cookie.setMaxAge(30*24*60*60);
			return cookie;
	}
		return cookie;
	}
}
