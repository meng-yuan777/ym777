package com.example.springbootssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import com.example.springbootssm.dao.noticdao.NoticDao;
import com.example.springbootssm.pojo.Notic;
import com.example.springbootssm.service.NoticService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("noticService")

public class NoticServiceImpl implements NoticService {

	@Resource
	private NoticDao noticDao;
	
	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void noticInsert(Notic notic) {
		// TODO Auto-generated method stub
		noticDao.noticInsert(notic);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void noticDelete(Integer id) {
		// TODO Auto-generated method stub
		noticDao.noticDelete(id);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void noticUpdate(Notic notic) {
		// TODO Auto-generated method stub
		noticDao.noticUpdate(notic);
	}

	@Override
	public List<Notic> noticSelectAll() {
		// TODO Auto-generated method stub
		return noticDao.noticSelectAll();
	}

	@Override
	public List<Notic> noticSelectByTitleAndContent(String title, String content) {
		// TODO Auto-generated method stub
		return noticDao.noticSelectByTitleAndContent(title, content);
	}

}
