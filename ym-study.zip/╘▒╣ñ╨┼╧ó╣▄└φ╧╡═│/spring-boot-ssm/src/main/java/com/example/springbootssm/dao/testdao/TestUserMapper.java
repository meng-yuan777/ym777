package com.example.springbootssm.dao.testdao;


import com.example.springbootssm.pojo.User;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface TestUserMapper {
    @Select("select * from user_inf")
    List<User> userSelect();
}
