package com.example.springbootssm.pojo;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Employee implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String name;
	private String card_id;
	private String address;
	private String phone;
	private Integer sex;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date birthday;
	private String mail;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date createdate;
	private Job job;
	private Dept dept;
	public Employee() {
		super();
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCard_id() {
		return card_id;
	}
	public void setCard_id(String card_id) {
		this.card_id = card_id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Integer getSex() {
		return sex;
	}
	public void setSex(Integer sex) {
		this.sex = sex;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}
	public Dept getDept() {
		return dept;
	}
	public void setDept(Dept dept) {
		this.dept = dept;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", card_id=" + card_id + ", address=" + address + ", phone="
				+ phone + ", sex=" + sex + ", birthday=" + birthday + ", mail=" + mail + ", createdate=" + createdate
				+ ", job=" + job + ", dept=" + dept + "]";
	}
	public Employee(Integer id, String name, String card_id, String address, String phone, Integer sex, Date birthday,
			String mail, Date createdate) {
		super();
		this.id = id;
		this.name = name;
		this.card_id = card_id;
		this.address = address;
		this.phone = phone;
		this.sex = sex;
		this.birthday = birthday;
		this.mail = mail;
		this.createdate = createdate;
	}
	
}
