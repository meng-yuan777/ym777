package com.example.springbootssm.controller.usercontroller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import com.example.springbootssm.pojo.User;
import com.example.springbootssm.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class UserController {
	//�û�����ӿ�ע��
	@Resource
	private UserService userService=null;
	
	@GetMapping("/userfindpage")
	public ModelAndView userAllSelect(ModelAndView mav) {
		List<User> users=userService.userSelectAll();
		mav.addObject("users", users);
		mav.setViewName("userfindpage");
		return mav;
	}
	
	@GetMapping("/userdelete/{userids}")
	public String userDelete(ModelAndView mav,@PathVariable("userids") String userids) {
		if(userids.contains(",")) {
			for(String id:userids.split(",")) {
				System.out.println(id);
				userService.userDelete(Integer.parseInt(id));
			}
		}
		else {
			userService.userDelete(Integer.parseInt(userids));
		}
		return "redirect:/userfindpage";
	}
	
	@GetMapping("/userselect")
	public ModelAndView userselect(@RequestParam("username")String username,@RequestParam("userstatus")String userstatus,ModelAndView mav) {
		List<User> users=userService.userSelectByUserNameOrUserStatus(username, userstatus);
		mav.addObject("users", users);
		mav.setViewName("userfindpage");
		return mav;
	}
	
	@RequestMapping(value="/userinsert")
	public void userinsert(@RequestBody User user,HttpServletResponse response) {
		System.out.println(user.toString());
		userService.userInsert(user);
	}
}
