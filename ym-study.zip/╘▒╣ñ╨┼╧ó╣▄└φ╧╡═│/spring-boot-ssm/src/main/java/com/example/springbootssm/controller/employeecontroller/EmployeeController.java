package com.example.springbootssm.controller.employeecontroller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import com.example.springbootssm.pojo.Dept;
import com.example.springbootssm.pojo.Employee;
import com.example.springbootssm.pojo.Job;
import com.example.springbootssm.service.DeptService;
import com.example.springbootssm.service.EmployeeService;
import com.example.springbootssm.service.JobService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	@Resource
	private EmployeeService employeeService=null;
	@Resource
	private DeptService deptService=null;
	@Resource
	private JobService jobService=null;
	@GetMapping("/employeefindpage")
	public ModelAndView employeeAllSelect(ModelAndView mav) {
		List<Employee> employees=employeeService.employeeSelectAll();
		mav.addObject("employees", employees);
		mav.setViewName("employeefindpage");
		return mav;
	}
	
	@GetMapping("/employeedelete/{employeeids}")
	public String employeeDelete(ModelAndView mav,@PathVariable("employeeids") String employeeids) {
		if(employeeids.contains(",")) {
			for(String id:employeeids.split(",")) {
				System.out.println(id);
				employeeService.employeeDelete(Integer.parseInt(id));
			}
		}
		else {
			employeeService.employeeDelete(Integer.parseInt(employeeids));
		}
		return "redirect:/employeefindpage";
	}
	
	@GetMapping("/employeeselect")
	public ModelAndView employeeSelect(@RequestParam("dept_id") String dept_name,@RequestParam("job_id") String job_name,
			@RequestParam("name") String name,@RequestParam("card_id") String card_id,
			@RequestParam("sex") String sex,
			@RequestParam("phone") String phone,ModelAndView mav) {
		List<Employee> employees=employeeService.employeeSelectByInformation(job_name, name, card_id, sex, phone, dept_name);
		System.out.println("qaq");
		employees.forEach(s->System.out.println(s.toString()));
		mav.addObject("employees", employees);
		mav.setViewName("employeefindpage");
		return mav;
	}
	
	@RequestMapping(value="/employeeinsert")
	public void employeeinsert(
			@ModelAttribute Employee employee,
			@RequestParam("dept_id")Integer dept_id,
			@RequestParam("job_id")Integer job_id,
			HttpServletResponse response) {
		System.out.println(employee.toString());
		Job job=jobService.jobSelectById(job_id);
		Dept dept=deptService.deptSelectById(dept_id);
		employee.setDept(dept);
		employee.setJob(job);
		employeeService.employeeInsert(employee);
	}
}
