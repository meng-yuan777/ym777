package com.example.springbootssm.controller.jobcontroller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import com.example.springbootssm.pojo.Job;
import com.example.springbootssm.service.JobService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JobController {
	@Resource
	private JobService jobService;
	
	@GetMapping("/jobfindpage")
	public ModelAndView jobAllSelect(ModelAndView mav) {
		List<Job> jobs=jobService.jobSelectAll();
		mav.addObject("jobs", jobs);
		mav.setViewName("jobfindpage");
		return mav;
	}
	
	@GetMapping("/jobdelete/{jobids}")
	public String jobDelete(ModelAndView mav,@PathVariable("jobids") String jobids) {
		if(jobids.contains(",")) {
			for(String id:jobids.split(",")) {
				System.out.println(id);
				jobService.jobDelete(Integer.parseInt(id));
			}
		}
		else {
			jobService.jobDelete(Integer.parseInt(jobids));
		}
		return "redirect:/jobfindpage";
	}
	
	@GetMapping("/jobselect")
	public ModelAndView userselect(@ModelAttribute Job job, ModelAndView mav) {
		List<Job> jobs=jobService.jobSelectByName(job);
		mav.addObject("jobs", jobs);
		mav.setViewName("jobfindpage");
		return mav;
	}
	
	@RequestMapping(value="/jobinsert")
	public void userinsert(@RequestBody Job job,HttpServletResponse response) {
		System.out.println(job.toString());
		jobService.jobInsert(job);;
	}
}
