package com.example.springbootssm.dao.jobdao;

import java.util.List;

import com.example.springbootssm.pojo.Job;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

public interface JobDao {
	//����ְλ
	@Insert("insert into job_inf(name) values(#{name})")
	@Options(useGeneratedKeys = true,keyProperty = "id")
	void jobInsert(Job job) ;
	
	//ɾ��ְλ
	@Delete("delete from job_inf where id=#{id}")
	void jobDelete(Integer id);
	
	//�޸�ְλ
	@Update("update job_inf set name={name} where id={id}")
	void jobUpdate(Job job);
	
	//����ְλ������ģ����ѯ
	List<Job> jobSelectByName(Job job);
	
	//����ְλid��ѯ
	@Select("select * from job_inf where id=#{id}")
	Job jobSelectById(Integer id);
	
	//��ѯ���й���
	@Select("select * from job_inf")
	List<Job> jobSelectAll();
}
