package com.example.springbootssm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.example.springbootssm.dao.employeedao.EmployeeDao;
import com.example.springbootssm.pojo.Employee;
import com.example.springbootssm.service.EmployeeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


@Service("employeeService")

public class EmployeeServiceImpl implements EmployeeService {
	@Resource
	private EmployeeDao employeeDao;

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void employeeInsert(Employee employee) {
		// TODO Auto-generated method stub
		employeeDao.employeeInsert(employee);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void employeeDelete(Integer id) {
		// TODO Auto-generated method stub
		employeeDao.employeeDelete(id);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void employeeUpdate(Employee employee) {
		// TODO Auto-generated method stub
		employeeDao.employeeUpdate(employee);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public List<Employee> employeeSelectByInformation(String job_id, String name, String card_id, String sex,
			String phone, String dept_id) {
		// TODO Auto-generated method stub
		Map<String, Object> param=new HashMap<>();
		if(!job_id.trim().equals(""))
			param.put("job_id", job_id.trim());
		if(!name.trim().equals(""))
			param.put("name", name.trim());
		if(!card_id.trim().equals(""))
			param.put("card_id", card_id.trim());
		if(!sex.trim().equals(""))
			param.put("sex", Integer.parseInt(sex.trim()));
		if(!phone.trim().equals(""))
			param.put("phone", phone.trim());
		if(!dept_id.trim().equals(""))
			param.put("dept_id", dept_id.trim());
		return employeeDao.employeeSelectByInformation(param);
	}

	@Override
	public List<Employee> employeeSelectAll() {
		// TODO Auto-generated method stub
		return employeeDao.employeeSelectAll();
	}
}
