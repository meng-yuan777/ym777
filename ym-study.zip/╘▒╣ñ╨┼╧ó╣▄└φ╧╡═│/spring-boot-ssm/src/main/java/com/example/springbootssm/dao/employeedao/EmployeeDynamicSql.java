package com.example.springbootssm.dao.employeedao;

import com.example.springbootssm.pojo.Employee;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;


public class EmployeeDynamicSql {

	// Ա�����µĶ�̬SQL
	public String employeeUpdate(Employee employee) {
		return new SQL() {
			{
				UPDATE("employee_inf");
				if (employee.getName() != null)
					SET("name=#{name}");
				if (employee.getCard_id() != null)
					SET("card_id=#{card_id}");
				if (employee.getAddress() != null)
					SET("address=#{address}");
				if (employee.getBirthday() != null)
					SET("birthday=#{birthday}");
				if (employee.getDept() != null)
					SET("dept_id=#{dept_id}");
				if (employee.getJob() != null)
					SET("job_id=#{job_id}");
				if (employee.getSex() != null)
					SET("sex=#{sex}");
				if (employee.getPhone() != null)
					SET("phone=#{phone}");
				if (employee.getMail() != null)
					SET("mail=#{mail}");
				WHERE("id=#{id}");
			}
		}.toString();
	}

	// Ա��ģ������ѯ�Ķ�̬SQL
//	public String employeeSelectByInformation(@Param("job_name") String job_name,@Param("name") String name,@Param("card_id") String card_id,
//			@Param("sex") String sex,@Param("phone") String phone,@Param("dept_name") String dept_name) {
//		System.out.println("sex:"+sex+" job_name:"+job_name+" dept_name:"+dept_name+"sex:"+sex+ "name:"+name);
//		return new SQL() {
//			
//			{
//				SELECT("*");
//				FROM("employee_inf");
//				if (job_name != null) {
//					WHERE("job_id in "+SELECT("id") +FROM("job_inf")
//							+ WHERE("name ="+job_name));
//				}
////				if (dept_name != null) {
////					WHERE("dept_id in (select id from dept_inf "
////							+ "where name ="+dept_name +")");
////				}
//				if (name != null)
//					WHERE("name like '%" + name + "%'");
//				if (card_id != null)
//					WHERE("card_id like '%" + card_id + "%'");
//				if (sex != null)
//					WHERE("sex like '%" + Integer.parseInt(sex) + "%'");
//			}
//		}.toString();
//	}
}
