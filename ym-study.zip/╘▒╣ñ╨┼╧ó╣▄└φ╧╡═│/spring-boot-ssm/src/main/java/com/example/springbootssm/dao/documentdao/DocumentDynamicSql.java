package com.example.springbootssm.dao.documentdao;


import com.example.springbootssm.pojo.Document;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;


public class DocumentDynamicSql {
		
		//�ļ�ģ����ѯ
		public String documentSelectByTitleAndContent(@Param("title") String title, @Param("content")String content) {
			return new SQL() {
				{
					SELECT("*");
					FROM("document_inf");
					if(title!=null)
						WHERE("title like %"+title+"%");
					if(content!=null)
						WHERE("content like %"+content+"%");
				}
			}.toString();
		}
		
		//�ļ����µĶ�̬SQL
		public String documentUpdate(Document document ) {
			return new SQL() {
				{
					UPDATE("document_inf");
					if(document.getContent()!=null)
						SET("content=#{content}");
					if(document.getTitle()!=null)
						SET("title=#{title}");
					WHERE("id=#{id}");
				}
				}.toString();
		}
}
