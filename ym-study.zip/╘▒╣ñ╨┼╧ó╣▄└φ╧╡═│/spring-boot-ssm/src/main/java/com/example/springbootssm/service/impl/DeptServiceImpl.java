package com.example.springbootssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import com.example.springbootssm.dao.deptdao.DeptDao;
import com.example.springbootssm.pojo.Dept;
import com.example.springbootssm.service.DeptService;
import com.example.springbootssm.service.JobService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("deptService")
public class DeptServiceImpl implements DeptService {

    @Resource
    private DeptDao deptDao = null;

    @Resource
    private JobService jobService = null;

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
    public void deptInsert(Dept dept) {
        // TODO Auto-generated method stub
//		jobService.jobInsert(new Job("qaq"));
        deptDao.deptInsert(dept);
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
    public void deptDelete(Integer id) {
        // TODO Auto-generated method stub
        deptDao.deptDelete(id);
    }

    @Override
    @Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
    public void deptUpdate(Dept dept) {
        // TODO Auto-generated method stub
        deptDao.deptUpdate(dept);
    }

    @Override
    public List<Dept> deptSelectByName(Dept dept) {
        // TODO Auto-generated method stub
        return deptDao.deptSelectByName(dept);
    }

    @Override
    public Dept deptSelectById(Integer id) {
        // TODO Auto-generated method stub
        return deptDao.deptSelectById(id);
    }

    @Override
    public List<Dept> deptSelectAll() {
        // TODO Auto-generated method stub
        return deptDao.deptSelectAll();
    }

}
