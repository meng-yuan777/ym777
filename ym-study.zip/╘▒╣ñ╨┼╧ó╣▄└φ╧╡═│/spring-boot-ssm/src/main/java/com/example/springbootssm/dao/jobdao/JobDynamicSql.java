package com.example.springbootssm.dao.jobdao;


public class JobDynamicSql {
}
