package com.example.springbootssm.dao.deptdao;


public class DeptDynamicSql {
}