package com.example.springbootssm.test;

import com.example.springbootssm.pojo.Dept;
import com.example.springbootssm.service.DeptService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class test {
	public static void main(String[]args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("classpath*:applicationContext.xml");
		System.out.println();
		DeptService d=(DeptService)ctx.getBean(DeptService.class);
		d.deptInsert(new Dept("qqq"));
	}
}
