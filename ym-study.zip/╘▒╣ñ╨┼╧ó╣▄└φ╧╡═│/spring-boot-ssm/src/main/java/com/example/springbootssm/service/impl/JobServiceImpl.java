package com.example.springbootssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import com.example.springbootssm.dao.jobdao.JobDao;
import com.example.springbootssm.pojo.Job;
import com.example.springbootssm.service.JobService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("jobService")

public class JobServiceImpl implements JobService {
	
	@Resource
	private JobDao jobDap=null;
	
	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void jobInsert(Job job) {
		// TODO Auto-generated method stub
		jobDap.jobInsert(job);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void jobDelete(Integer id) {
		// TODO Auto-generated method stub
		jobDap.jobDelete(id);
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED,propagation = Propagation.REQUIRED)
	public void jobUpdate(Job job) {
		// TODO Auto-generated method stub
		jobDap.jobUpdate(job);
	}

	@Override
	public List<Job> jobSelectByName(Job job) {
		// TODO Auto-generated method stub
		return jobDap.jobSelectByName(job);
	}

	@Override
	public Job jobSelectById(Integer id) {
		// TODO Auto-generated method stub
		return jobDap.jobSelectById(id);
	}

	@Override
	public List<Job> jobSelectAll() {
		// TODO Auto-generated method stub
		return jobDap.jobSelectAll();
	}

}
