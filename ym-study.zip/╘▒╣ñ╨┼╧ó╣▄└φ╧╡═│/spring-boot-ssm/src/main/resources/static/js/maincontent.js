/**
 * 
 */
		$(".btn-user").click(function(){
			if($(".btn-user ul").is(":hidden")){
				$(".btn-user ul").show();
			}
			else $(".btn-user ul").hide();
		})
		
		$(".btn-job").click(function(){
			if($(".btn-job ul").is(":hidden")){
				$(".btn-job ul").show();
			}
			else $(".btn-job ul").hide();
		})
		$(".btn-dept").click(function(){
			if($(".btn-dept ul").is(":hidden")){
				$(".btn-dept ul").show();
			}
			else $(".btn-dept ul").hide();
		})
		$(".btn-employee").click(function(){
			if($(".btn-employee ul").is(":hidden")){
				$(".btn-employee ul").show();
			}
			else $(".btn-employee ul").hide();
		})
		$(".btn-document").click(function(){
			if($(".btn-document ul").is(":hidden")){
				$(".btn-document ul").show();
			}
			else $(".btn-document ul").hide();
		})
		$(".btn-notic").click(function(){
			if($(".btn-notic ul").is(":hidden")){
				$(".btn-notic ul").show();
			}
			else $(".btn-notic ul").hide();
		})
