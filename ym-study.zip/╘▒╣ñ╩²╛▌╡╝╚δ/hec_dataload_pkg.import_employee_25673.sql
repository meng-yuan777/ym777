WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR  EXIT FAILURE ROLLBACK;
spool hec_dataload_pkg.import_employee_25673.log
set feedback off
set define off
begin
hec_dataload_pkg.import_employee_25673('1','qweqwe','cc','yanbing.cao@hand-china.com','13888888888','','','Y','30','����֤','530124199406091625','');
hec_dataload_pkg.import_employee_25673('2','12312312','ym','123@qq.com','13777777777','','','N','20','','360502199706300000','');
end;
/
commit;

set feedback on
set define on
spool off







